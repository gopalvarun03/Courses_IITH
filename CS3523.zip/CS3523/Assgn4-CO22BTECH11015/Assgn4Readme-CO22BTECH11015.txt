rw-CO22BTECH11015.cpp contains the writers preference solution and frw-CO22BTECH11015.cpp contains the fair readers writers solution. The inp-params.txt file contains the input in the form: "Nw" "Nr" "Kw" "Kr" "ucs" "urem".
To compile and execute the codes: 
g++ rw-CO22BTECH11015.cpp
./a.out for 1st part
g++ frw-CO22BTECH11015.cpp
./a.out for 2nd part.
The above commands are to be run in linux terminal.
After the execution, RW-log.txt contains logfiles for the first part, FairRW-log.txt contains the log file for 2nd part. The Average_time.txt for part 1 and Average_time2.txt for part 2. Additionally a time.txt and time2.txt is created for part one and part 2 respectively which store the average and worst case times found out in a tabular format along with the input parameters.
