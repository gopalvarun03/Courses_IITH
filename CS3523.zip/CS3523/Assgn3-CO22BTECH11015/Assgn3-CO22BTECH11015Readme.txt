Input file:-input.txt
Output file:-OutFile{Method_no} in the order TAS,CAS,BCAS,Atomic Increment
The source code takes the input from the file in the order N, K,rowinc performs the computations and prints the time taken and the resultant matrix in outfiles.